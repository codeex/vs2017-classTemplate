﻿/*----------------------------------------------------------------
 Copyright (C) 2018 上海科箭软件科技有限公司版权所有

 创建者：   $username$
 创建时间： $time$
 文件：    $itemname$.cs
 功能描述：

----------------------------------------------------------------*/
namespace $rootnamespace$
{
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Quantum.FrameworkNetCore.Protocol.RpcProtocol;
using Quantum.FrameworkNetCore.Rpc.Server;
using Quantum.FrameworkNetCore.ExceptionEx;
using Quantum.FrameworkNetCore.DB.EFEx.DynamicSearch;

    /// <summary>
    /// $safeitemname$接口输入参数
    /// </summary>
    public class $safeitemname$Args 
    {

    }

    /// <summary>
    /// $safeitemname$接口输出参数
    /// </summary>
    public class $safeitemname$Result 
    {

    }
}
